export { resumeData } from './resume';
