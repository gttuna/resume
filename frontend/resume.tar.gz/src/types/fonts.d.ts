declare module '@fontsource-variable/roboto-flex';
